export default function CompletedPage() {
  return (
    <>
      <h1>Completed</h1>
      <div className="panel"><p>Completed fulfilment orders.</p></div>
    </>
  )
}
