import { orders } from '../../data/orders'

export default function DashboardPage() {
  return (
    <>
      <h1>Fulfilment Dashboard</h1>
      <div className="stats">
        <div><span>Paid orders</span><strong>{orders.length}</strong></div>
        <div><span>Picking</span><strong>1</strong></div>
        <div><span>Packing</span><strong>1</strong></div>
        <div><span>Ready to dispatch</span><strong>0</strong></div>
      </div>
    </>
  )
}
