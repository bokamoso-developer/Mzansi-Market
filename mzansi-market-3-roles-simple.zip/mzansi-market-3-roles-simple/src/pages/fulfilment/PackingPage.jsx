export default function PackingPage() {
  return (
    <>
      <h1>Packing</h1>
      <div className="panel"><p>Orders currently being packed.</p></div>
    </>
  )
}
