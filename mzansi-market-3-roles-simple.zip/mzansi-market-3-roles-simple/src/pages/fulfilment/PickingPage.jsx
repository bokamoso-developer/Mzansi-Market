export default function PickingPage() {
  return (
    <>
      <h1>Picking</h1>
      <div className="panel"><p>Orders currently being picked.</p></div>
    </>
  )
}
