import { useParams } from 'react-router-dom'
import { orders } from '../../data/orders'

export default function OrderPage() {
  const { id } = useParams()
  const order = orders.find((item) => item.id === id)

  if (!order) return <p>Order not found.</p>

  return (
    <>
      <h1>Order {order.id}</h1>

      <div className="panel">
        <p><strong>Customer:</strong> {order.customer}</p>
        <p><strong>Items:</strong> {order.items}</p>
        <p><strong>Payment:</strong> {order.paymentStatus}</p>
        <p><strong>Status:</strong> {order.fulfilmentStatus}</p>

        <div className="actions">
          <button>Reserve stock</button>
          <button>Start picking</button>
          <button>Mark picked</button>
          <button>Start packing</button>
          <button>Mark packed</button>
          <button>Ready for dispatch</button>
        </div>
      </div>
    </>
  )
}
