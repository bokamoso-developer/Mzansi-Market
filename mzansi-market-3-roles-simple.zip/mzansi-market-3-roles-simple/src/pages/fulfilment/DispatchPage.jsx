export default function DispatchPage() {
  return (
    <>
      <h1>Dispatch</h1>
      <div className="panel"><p>Orders ready for dispatch.</p></div>
    </>
  )
}
