import { Link } from 'react-router-dom'
import { orders } from '../../data/orders'
import { money } from '../../utils'

export default function OrdersPage() {
  return (
    <>
      <h1>Paid orders</h1>

      <div className="table-card">
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Total</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{order.customer}</td>
                <td>{order.items}</td>
                <td>{money(order.total)}</td>
                <td>{order.fulfilmentStatus}</td>
                <td><Link to={`/fulfilment/order/${order.id}`}>Open</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
