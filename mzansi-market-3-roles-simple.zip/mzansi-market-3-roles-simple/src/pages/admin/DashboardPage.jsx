import { products } from '../../data/products'

export default function DashboardPage() {
  const lowStock = products.filter((p) => p.stock < 10).length

  return (
    <>
      <h1>Product Dashboard</h1>
      <div className="stats">
        <div><span>Products</span><strong>{products.length}</strong></div>
        <div><span>Low stock</span><strong>{lowStock}</strong></div>
        <div><span>Categories</span><strong>3</strong></div>
        <div><span>Promotions</span><strong>0</strong></div>
      </div>
    </>
  )
}
