import { Link } from 'react-router-dom'
import { products } from '../../data/products'
import { money } from '../../utils'

export default function ProductsPage() {
  return (
    <>
      <div className="staff-heading">
        <h1>Products</h1>
        <Link className="primary-link" to="/admin/products/new">Add product</Link>
      </div>

      <div className="table-card">
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>{product.name}</td>
                <td>{product.category}</td>
                <td>{money(product.price)}</td>
                <td>{product.stock}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  )
}
