export default function ProductFormPage() {
  return (
    <>
      <h1>Add product</h1>
      <div className="panel form product-form">
        <input placeholder="Product name" />
        <input placeholder="SKU" />
        <input placeholder="Category" />
        <input type="number" placeholder="Price" />
        <input type="number" placeholder="Stock" />
        <textarea rows="5" placeholder="Description" />
        <input type="file" />
        <button>Save product</button>
      </div>
    </>
  )
}
