import { useParams } from 'react-router-dom'
import { products } from '../../data/products'
import { useCart } from '../../context/CartContext'
import { money } from '../../utils'

export default function ProductPage() {
  const { id } = useParams()
  const product = products.find((item) => item.id === Number(id))
  const { addToCart } = useCart()

  if (!product) return <div className="container section">Product not found.</div>

  return (
    <section className="container product-page">
      <div className="large-image">{product.name}</div>

      <div>
        <span className="eyebrow">{product.category}</span>
        <h1>{product.name}</h1>
        <h2>{money(product.price)}</h2>
        <p>Quality product available through Mzansi Market.</p>
        <p><strong>{product.stock}</strong> in stock</p>
        <button onClick={() => addToCart(product)}>Add to cart</button>
      </div>
    </section>
  )
}
