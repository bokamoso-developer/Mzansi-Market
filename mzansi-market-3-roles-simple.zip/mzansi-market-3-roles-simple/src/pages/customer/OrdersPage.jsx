import { orders } from '../../data/orders'
import { money } from '../../utils'

export default function OrdersPage() {
  return (
    <section className="container section">
      <h1>My orders</h1>

      <div className="table-card">
        <table>
          <thead>
            <tr>
              <th>Order</th>
              <th>Total</th>
              <th>Payment</th>
              <th>Fulfilment</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>{order.id}</td>
                <td>{money(order.total)}</td>
                <td>{order.paymentStatus}</td>
                <td>{order.fulfilmentStatus}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
