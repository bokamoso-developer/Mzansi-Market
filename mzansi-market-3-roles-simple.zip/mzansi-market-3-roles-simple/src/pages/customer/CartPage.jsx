import { Link } from 'react-router-dom'
import { useCart } from '../../context/CartContext'
import { money } from '../../utils'

export default function CartPage() {
  const { items, removeFromCart, total } = useCart()

  return (
    <section className="container section">
      <h1>Your cart</h1>

      <div className="two-column">
        <div className="panel">
          {items.length === 0 && <p>Your cart is empty.</p>}

          {items.map((item) => (
            <div className="cart-row" key={item.id}>
              <div>
                <strong>{item.name}</strong>
                <p>Quantity: {item.quantity}</p>
              </div>
              <div>
                <strong>{money(item.price * item.quantity)}</strong>
                <button onClick={() => removeFromCart(item.id)}>Remove</button>
              </div>
            </div>
          ))}
        </div>

        <aside className="panel">
          <h3>Order summary</h3>
          <p>Total: <strong>{money(total)}</strong></p>
          <Link className="primary-link full" to="/checkout">Checkout</Link>
        </aside>
      </div>
    </section>
  )
}
