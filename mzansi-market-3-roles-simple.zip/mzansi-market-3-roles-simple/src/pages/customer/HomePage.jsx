import { Link } from 'react-router-dom'
import ProductCard from '../../components/ProductCard'
import { products } from '../../data/products'

export default function HomePage() {
  return (
    <>
      <section className="hero container">
        <div>
          <span className="eyebrow">Proudly South African</span>
          <h1>Shop local.<br />Support Mzansi.</h1>
          <p>Discover products from local South African businesses and makers.</p>
          <Link className="primary-link" to="/shop">Shop now</Link>
        </div>
        <div className="hero-art">Mzansi Market</div>
      </section>

      <section className="container section">
        <div className="section-heading">
          <div>
            <span className="eyebrow">Discover</span>
            <h2>Featured products</h2>
          </div>
          <Link to="/shop">View all</Link>
        </div>

        <div className="product-grid">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </>
  )
}
