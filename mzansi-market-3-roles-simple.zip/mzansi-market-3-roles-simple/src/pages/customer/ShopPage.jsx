import ProductCard from '../../components/ProductCard'
import { products } from '../../data/products'

export default function ShopPage() {
  return (
    <section className="container section">
      <div className="section-heading">
        <div>
          <span className="eyebrow">Mzansi Market</span>
          <h1>Shop</h1>
        </div>
        <input className="search" placeholder="Search products..." />
      </div>

      <div className="product-grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  )
}
