export const products = [
  { id: 1, name: 'African Print Tote Bag', category: 'Fashion', price: 349, stock: 21 },
  { id: 2, name: 'Ceramic Coffee Mug', category: 'Home', price: 189, stock: 12 },
  { id: 3, name: 'Mzansi Hoodie', category: 'Fashion', price: 699, stock: 8 },
  { id: 4, name: 'Natural Body Butter', category: 'Beauty', price: 159, stock: 30 }
]
