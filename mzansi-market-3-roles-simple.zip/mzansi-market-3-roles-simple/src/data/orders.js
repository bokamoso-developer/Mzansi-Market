export const orders = [
  {
    id: 'MM1001',
    customer: 'Naledi Mokoena',
    total: 1048,
    paymentStatus: 'Paid',
    fulfilmentStatus: 'Pending',
    items: 2,
  },
  {
    id: 'MM1002',
    customer: 'Thabo Molefe',
    total: 538,
    paymentStatus: 'Paid',
    fulfilmentStatus: 'Picking',
    items: 3,
  },
  {
    id: 'MM1003',
    customer: 'Lerato Dlamini',
    total: 699,
    paymentStatus: 'Paid',
    fulfilmentStatus: 'Packing',
    items: 1,
  },
]
