import { Link } from 'react-router-dom'
import { ShoppingBag, UserRound } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

export default function Header() {
  const { user, logout } = useAuth()
  const { items } = useCart()
  const count = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <header className="header">
      <div className="container header-inner">
        <Link to="/" className="logo">Mzansi Market</Link>

        <nav>
          <Link to="/">Home</Link>
          <Link to="/shop">Shop</Link>
          {user?.role === 'customer' && <Link to="/orders">Orders</Link>}
        </nav>

        <div className="header-actions">
          <Link to="/cart" className="cart">
            <ShoppingBag size={20} />
            {count > 0 && <span>{count}</span>}
          </Link>

          {user ? (
            <>
              <UserRound size={20} />
              <button className="link-button" onClick={logout}>Logout</button>
            </>
          ) : (
            <Link to="/login">Login</Link>
          )}
        </div>
      </div>
    </header>
  )
}
