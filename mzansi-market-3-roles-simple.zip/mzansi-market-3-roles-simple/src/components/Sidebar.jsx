import { NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Sidebar({ title, links }) {
  const { logout } = useAuth()

  return (
    <aside className="sidebar">
      <div>
        <div className="logo">Mzansi Market</div>
        <small>{title}</small>
      </div>

      <nav>
        {links.map((link) => (
          <NavLink key={link.to} to={link.to} end={link.end}>
            {link.label}
          </NavLink>
        ))}
      </nav>

      <button onClick={logout}>Logout</button>
    </aside>
  )
}
