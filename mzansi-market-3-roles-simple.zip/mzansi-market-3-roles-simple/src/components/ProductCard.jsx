import { Link } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { money } from '../utils'

export default function ProductCard({ product }) {
  const { addToCart } = useCart()

  return (
    <article className="product-card">
      <Link to={`/product/${product.id}`} className="product-image">
        {product.name}
      </Link>

      <div className="product-info">
        <small>{product.category}</small>
        <h3>{product.name}</h3>
        <strong>{money(product.price)}</strong>
        <button onClick={() => addToCart(product)}>Add to cart</button>
      </div>
    </article>
  )
}
