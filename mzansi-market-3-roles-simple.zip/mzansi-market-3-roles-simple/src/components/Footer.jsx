export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <strong>Mzansi Market</strong>
        <p>Shop local. Support Mzansi.</p>
      </div>
    </footer>
  )
}
