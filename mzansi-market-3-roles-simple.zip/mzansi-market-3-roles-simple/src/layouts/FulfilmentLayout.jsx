import { Outlet } from 'react-router-dom'
import Sidebar from '../components/Sidebar'

const links = [
  { to: '/fulfilment', label: 'Dashboard', end: true },
  { to: '/fulfilment/orders', label: 'Paid Orders' },
  { to: '/fulfilment/picking', label: 'Picking' },
  { to: '/fulfilment/packing', label: 'Packing' },
  { to: '/fulfilment/dispatch', label: 'Dispatch' },
  { to: '/fulfilment/completed', label: 'Completed' },
]

export default function FulfilmentLayout() {
  return (
    <div className="staff-layout">
      <Sidebar title="Fulfilment Employee" links={links} />
      <main className="staff-main"><Outlet /></main>
    </div>
  )
}
